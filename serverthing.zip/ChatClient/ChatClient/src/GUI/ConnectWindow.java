package GUI;

import javax.swing.JDialog;

public class ConnectWindow extends JDialog{
    
}
